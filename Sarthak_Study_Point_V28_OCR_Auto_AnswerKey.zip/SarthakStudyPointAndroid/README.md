# Sarthak Study Point Android App — v2.1

This Android project opens the current Sarthak Study Point exam-preparation interface from a bundled local HTML asset, so the app opens without depending on the live website being reachable. It includes General Exam Preparation, Railway GDCE/LDCE, Sarthak Score (local result history), Admin Upload, and the bundled GDCE JE Civil CBT/PDF resources.

**Branding:** the slim top identity strip reads “ROHIT KUMAR · FOUNDER | OWNER”.

## Build
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- Java 17
- Android SDK 36
- `gradle assembleDebug`

The generated debug APK is for testing. For public Play Store release, configure a permanent release signing key, privacy disclosures, and a secure backend for shared accounts/content.
