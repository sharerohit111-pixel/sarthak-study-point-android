# Sarthak Study Point — Android App Starter

## इस पैकेज में क्या है
- Android Studio project (Java + Android WebView shell)
- Live website: https://sarthak-study-point.pages.dev/
- App header पर SARTHAK STUDY POINT और ROHIT KUMAR • FOUNDER | OWNER
- Home / GDCE JE Civil CBT / Practice PDF quick actions
- 150 प्रश्नों वाला bilingual GDCE JE Civil CBT ऐप में bundled है और ऑफलाइन चलता है
- GDCE JE Civil Practice Paper (Hindi) PDF bundled है
- Website के भीतर PDF/download और Admin upload file-picker support
- Website के लिए PWA manifest, service worker और 192/512 icons

## Android APK बनाने के लिए
1. कंप्यूटर पर Android Studio का नवीनतम stable संस्करण इंस्टॉल करें।
2. Android SDK Platform 36 और Android SDK Build Tools इंस्टॉल करें।
3. इस ZIP को extract करें।
4. Android Studio → Open → इस folder `SarthakStudyPointAndroid` को चुनें।
5. Gradle sync पूरा होने दें। इंटरनेट कनेक्शन चाहिए ताकि Gradle/AndroidX dependencies डाउनलोड हो सकें।
6. Build → Build Bundle(s) / APK(s) → Build APK(s) चुनें।
7. Debug APK `app/build/outputs/apk/debug/` में बनेगा।

## Google Play Store के लिए
1. Android Studio में Build → Generate Signed Bundle / APK चुनें।
2. Android App Bundle (AAB) चुनें और अपनी सुरक्षित upload key बनाएँ। Keystore और passwords सुरक्षित रखें; इन्हें किसी के साथ साझा न करें।
3. Release AAB बनाकर Google Play Console में अपलोड करें।
4. Store listing, screenshots, privacy policy, Data safety form, content rating और testing requirements पूरी करें।
5. इस प्रोजेक्ट का targetSdk 36 रखा गया है। 3 Nov 2026 के अनुसार Google Play के नए ऐप और अपडेट के लिए Android 16 / API 36 की शर्त लागू है।

## वेबसाइट के लिए PWA installability
`website-pwa/` के चार assets को GitHub repository `sharerohit111-pixel/sarthak-study-point` की root में copy करें:
- `manifest.webmanifest`
- `sw.js`
- `icon-192.png`
- `icon-512.png`

फिर `pwa-integration-snippet.html` में दिए गए tags को website के `<head>` और `</body>` से पहले जोड़ें। GitHub की `main` branch पर push होने के बाद Cloudflare Pages deployment स्वतः शुरू होना चाहिए।

## महत्वपूर्ण उत्पादन-पूर्व काम
मौजूदा live website में login/role control, cloud database, shared PDF storage और वास्तविक payment gateway अभी production-ready नहीं हैं। वेबसाइट पर Admin/Teacher/Student flows के कुछ हिस्से demo/prototype हैं और device-local storage पर निर्भर हैं। Play Store पर सार्वजनिक रिलीज़ से पहले:
- Secure server-side authentication और role permissions
- Shared database तथा server-side file/PDF storage
- Payment gateway और order verification (यदि paid content बेचना है)
- Privacy policy, data deletion/contact process और Data safety disclosures
- Admin panel को public users से सुरक्षित करना
जोड़ना और वास्तविक उपकरणों पर परीक्षण करना आवश्यक है।

## Package details
- Application ID: `com.sarthakstudypoint.app`
- Minimum Android: 6.0 (API 23)
- Target Android: 16 (API 36)
- Version: 1.0
- App source: `app/src/main/`

## GitHub Actions से APK बनाना (कंप्यूटर के बिना भी)
इस ZIP को अपने GitHub repository में source के रूप में upload/push करने के बाद Actions टैब में `Build Sarthak Study Point APK` workflow चलाएँ। सफल build पर `sarthak-study-point-debug-apk` नाम का artifact मिलेगा। यह testing APK होगा; Play Store के लिए signed release AAB अलग से बनाना होगा।
