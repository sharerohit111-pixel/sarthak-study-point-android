# Sarthak Study Point Android App

See `docs/README_HINDI.md` for build and release instructions.
