package com.sarthakstudypoint.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://sarthak-study-point.pages.dev/";
    private static final String SITE_HOST = "sarthak-study-point.pages.dev";
    private WebView webView;
    private ProgressBar progress;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_PICKER_REQUEST = 4102;
    private String currentMode = "site";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        WindowCompat.setDecorFitsSystemWindows(window, false);
        window.setStatusBarColor(android.graphics.Color.rgb(7, 26, 53));
        window.setNavigationBarColor(android.graphics.Color.rgb(7, 26, 53));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(android.graphics.Color.WHITE);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });

        TextView brand = new TextView(this);
        brand.setText("SARTHAK STUDY POINT");
        brand.setTextColor(android.graphics.Color.WHITE);
        brand.setTextSize(17);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setPadding(dp(16), dp(10), dp(16), dp(1));
        brand.setTypeface(null, android.graphics.Typeface.BOLD);
        brand.setBackgroundColor(android.graphics.Color.rgb(7, 26, 53));
        root.addView(brand, new LinearLayout.LayoutParams(-1, dp(38)));

        TextView owner = new TextView(this);
        owner.setText("ROHIT KUMAR  •  FOUNDER | OWNER");
        owner.setTextColor(android.graphics.Color.rgb(251, 191, 36));
        owner.setTextSize(11);
        owner.setPadding(dp(16), 0, dp(16), dp(8));
        owner.setBackgroundColor(android.graphics.Color.rgb(7, 26, 53));
        root.addView(owner, new LinearLayout.LayoutParams(-1, dp(25)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(8), dp(7), dp(8), dp(7));
        nav.setBackgroundColor(android.graphics.Color.rgb(239, 244, 251));
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(52)));

        Button home = navButton("Home");
        Button cbt = navButton("GDCE JE Civil CBT");
        Button pdf = navButton("Practice PDF");
        nav.addView(home, new LinearLayout.LayoutParams(0, -1, 1f));
        nav.addView(cbt, new LinearLayout.LayoutParams(0, -1, 1.55f));
        nav.addView(pdf, new LinearLayout.LayoutParams(0, -1, 1.15f));
        home.setOnClickListener(v -> loadHome());
        cbt.setOnClickListener(v -> loadCbt());
        pdf.setOnClickListener(v -> openPracticePdf());

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));

        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.WHITE);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setLoadsImagesAutomatically(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme()) && SITE_HOST.equalsIgnoreCase(uri.getHost())) {
                    return false;
                }
                if ("file".equalsIgnoreCase(uri.getScheme()) || "about".equalsIgnoreCase(uri.getScheme())) {
                    return false;
                }
                openExternal(uri);
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showOfflinePage();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/*", "video/*"});
                try {
                    startActivityForResult(Intent.createChooser(intent, "Select study material"), FILE_PICKER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    uploadCallback = null;
                    Toast.makeText(MainActivity.this, "File picker is not available.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimeType);
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null) request.addRequestHeader("cookie", cookies);
                request.addRequestHeader("User-Agent", userAgent);
                request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
                request.setDescription("Downloading from Sarthak Study Point");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url, contentDisposition, mimeType));
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Download could not be started.", Toast.LENGTH_LONG).show();
            }
        });

        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        loadHome();
    }

    private Button navButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setTextColor(android.graphics.Color.rgb(7, 26, 53));
        b.setPadding(dp(3), 0, dp(3), 0);
        return b;
    }

    private void loadHome() {
        currentMode = "site";
        webView.loadUrl(HOME_URL);
    }

    private void loadCbt() {
        currentMode = "cbt";
        webView.loadUrl("file:///android_asset/gdce_je_civil_cbt.html");
    }

    private void openPracticePdf() {
        try {
            File out = new File(getCacheDir(), "GDCE_JE_Civil_Practice_Paper_Hindi.pdf");
            try (InputStream in = getAssets().open("gdce_je_civil_practice_paper_hindi.pdf");
                 FileOutputStream fos = new FileOutputStream(out)) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) > 0) fos.write(buffer, 0, n);
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", out);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Open GDCE JE Civil Practice Paper"));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "PDF viewer app not found. Install a PDF reader.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "PDF could not be opened.", Toast.LENGTH_LONG).show();
        }
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) {
            Toast.makeText(this, "No app found to open this link.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showOfflinePage() {
        String html = "<!doctype html><html><meta name='viewport' content='width=device-width,initial-scale=1'><body style='font-family:Arial;background:#f4f7fb;color:#071a35;padding:28px;text-align:center'><h2>Sarthak Study Point</h2><h3>इंटरनेट कनेक्शन उपलब्ध नहीं है</h3><p>कृपया इंटरनेट चालू करके दोबारा प्रयास करें।</p><button onclick='location.href=\"" + HOME_URL + "\"' style='padding:14px 22px;background:#2563eb;color:white;border:0;border-radius:10px'>Retry</button><p>GDCE JE Civil CBT और Practice PDF ऐप में ऑफलाइन उपलब्ध हैं।</p></body></html>";
        webView.loadDataWithBaseURL(HOME_URL, html, "text/html", "UTF-8", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER_REQUEST && uploadCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
            }
            uploadCallback.onReceiveValue(results);
            uploadCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if ("cbt".equals(currentMode)) {
            loadHome();
        } else if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        if (uploadCallback != null) uploadCallback.onReceiveValue(null);
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
