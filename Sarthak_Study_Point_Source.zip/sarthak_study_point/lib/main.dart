import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color mapBlue = Color(0xFF1683E8);
const Color deepBlue = Color(0xFF0864B5);
const Color paleBlue = Color(0xFFEAF4FF);

void main() => runApp(const SarthakApp());

class SarthakApp extends StatelessWidget {
  const SarthakApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Sarthak Study Point',
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xFFF7FAFE),
          colorScheme: ColorScheme.fromSeed(seedColor: mapBlue, primary: mapBlue),
          appBarTheme: const AppBarTheme(backgroundColor: mapBlue, foregroundColor: Colors.white, centerTitle: true),
          cardTheme: CardThemeData(color: Colors.white, elevation: 1, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
          inputDecorationTheme: InputDecorationTheme(
            filled: true, fillColor: const Color(0xFFF7FAFE),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: Color(0xFFD8E7F7))),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: Color(0xFFD8E7F7))),
          ),
        ),
        home: const HomePage(),
      );
}

class StudyItem {
  StudyItem({required this.id, required this.exam, required this.section, required this.title, required this.kind,
    this.fileName = '', this.questions = const [], this.duration = 60, this.marks = 100,
    this.negative = 0.25, this.price = 0, this.isFree = true});
  final String id, exam, section, title, kind, fileName;
  final List<Question> questions;
  final int duration, marks;
  final double negative, price;
  final bool isFree;
  Map<String, dynamic> toJson() => {'id':id,'exam':exam,'section':section,'title':title,'kind':kind,'fileName':fileName,
    'questions':questions.map((q)=>q.toJson()).toList(),'duration':duration,'marks':marks,'negative':negative,'price':price,'isFree':isFree};
  factory StudyItem.fromJson(Map<String,dynamic> j) => StudyItem(id:j['id'],exam:j['exam'],section:j['section'],title:j['title'],kind:j['kind'],fileName:j['fileName']??'',
    questions:(j['questions'] as List? ?? []).map((e)=>Question.fromJson(Map<String,dynamic>.from(e))).toList(),duration:j['duration']??60,marks:j['marks']??100,
    negative:(j['negative']??0.25).toDouble(),price:(j['price']??0).toDouble(),isFree:j['isFree']??true);
}

class Question {
  Question({required this.text, required this.options, required this.answer, this.explanation = ''});
  final String text; final List<String> options; final int answer; final String explanation;
  Map<String,dynamic> toJson()=>{'text':text,'options':options,'answer':answer,'explanation':explanation};
  factory Question.fromJson(Map<String,dynamic> j)=>Question(text:j['text'],options:List<String>.from(j['options']),answer:j['answer'],explanation:j['explanation']??'');
}

class AppStore extends ChangeNotifier {
  AppStore._();
  static final AppStore instance = AppStore._();
  final List<StudyItem> items = [];
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('study_items');
    if (raw != null) {
      try { items..clear()..addAll((jsonDecode(raw) as List).map((e)=>StudyItem.fromJson(Map<String,dynamic>.from(e)))); } catch (_) {}
    }
    notifyListeners();
  }
  Future<void> add(StudyItem item) async { items.insert(0,item); await save(); }
  Future<void> remove(String id) async { items.removeWhere((e)=>e.id==id); await save(); }
  Future<void> save() async { final p=await SharedPreferences.getInstance(); await p.setString('study_items',jsonEncode(items.map((e)=>e.toJson()).toList())); notifyListeners(); }
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  @override void initState(){super.initState();AppStore.instance.load();}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(title: const Text('Sarthak Study Point',style:TextStyle(fontWeight:FontWeight.w800)),actions:[IconButton(tooltip:'Admin',onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AdminPage())),icon:const Icon(Icons.admin_panel_settings_outlined))]),
    body: ListView(padding:const EdgeInsets.all(18),children:[
      Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[mapBlue,deepBlue]),borderRadius:BorderRadius.circular(22)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(Icons.train_rounded,color:Colors.white,size:38),SizedBox(height:12),Text('Railway Exam Preparation',style:TextStyle(color:Colors.white,fontSize:21,fontWeight:FontWeight.bold)),SizedBox(height:5),Text('Focused preparation for GDCE & LDCE',style:TextStyle(color:Colors.white70))])),
      const SizedBox(height:24),const Text('Choose Your Examination',style:TextStyle(fontSize:19,fontWeight:FontWeight.w800)),const SizedBox(height:12),
      ExamCard(title:'GDCE',subtitle:'General Departmental Competitive Examination',icon:Icons.train_rounded,onTap:()=>openExam(context,'GDCE')),
      ExamCard(title:'LDCE',subtitle:'Limited Departmental Competitive Examination',icon:Icons.menu_book_rounded,onTap:()=>openExam(context,'LDCE')),
      const SizedBox(height:18),const Center(child:Text('Learn • Practice • Achieve',style:TextStyle(color:Colors.blueGrey))),
    ]),
  );
}

void openExam(BuildContext context,String exam)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ExamPage(exam:exam)));

class ExamCard extends StatelessWidget {
  const ExamCard({super.key,required this.title,required this.subtitle,required this.icon,required this.onTap});
  final String title,subtitle; final IconData icon; final VoidCallback onTap;
  @override Widget build(BuildContext context)=>Card(margin:const EdgeInsets.only(bottom:13),child:InkWell(borderRadius:BorderRadius.circular(18),onTap:onTap,child:Padding(padding:const EdgeInsets.all(18),child:Row(children:[Container(width:55,height:55,decoration:BoxDecoration(color:paleBlue,borderRadius:BorderRadius.circular(15)),child:Icon(icon,color:deepBlue,size:30)),const SizedBox(width:15),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:4),Text(subtitle,style:const TextStyle(fontSize:12,color:Colors.blueGrey))])),const Icon(Icons.chevron_right,color:deepBlue,size:30)]))));
}

const sections = [
  ('Previous Year Paper','Year-wise question papers and PDFs',Icons.description_outlined),
  ('Mock Test','CBT-style timed examinations',Icons.assignment_turned_in_outlined),
  ('Study Material','Notes and topic-wise PDFs',Icons.menu_book_outlined),
  ('Practice Series','Topic-wise practice sets',Icons.track_changes_outlined),
];

class ExamPage extends StatelessWidget {
  const ExamPage({super.key,required this.exam}); final String exam;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(exam)),body:ListView(padding:const EdgeInsets.all(16),children:[
    Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:paleBlue,borderRadius:BorderRadius.circular(18)),child:Row(children:[const Icon(Icons.train_rounded,color:deepBlue,size:42),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(exam,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900,color:deepBlue)),const Text('Select a learning section',style:TextStyle(color:Colors.blueGrey))]))])),const SizedBox(height:18),
    ...sections.map((s)=>Card(child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:16,vertical:9),leading:Container(width:46,height:46,decoration:BoxDecoration(color:paleBlue,borderRadius:BorderRadius.circular(13)),child:Icon(s.$3,color:deepBlue)),title:Text(s.$1,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text(s.$2,style:const TextStyle(fontSize:12)),trailing:const Icon(Icons.chevron_right,color:deepBlue),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ContentPage(exam:exam,section:s.$1))))))
  ]));
}

class ContentPage extends StatefulWidget { const ContentPage({super.key,required this.exam,required this.section}); final String exam,section; @override State<ContentPage> createState()=>_ContentPageState(); }
class _ContentPageState extends State<ContentPage> {
  @override Widget build(BuildContext context){final items=AppStore.instance.items.where((e)=>e.exam==widget.exam&&e.section==widget.section).toList();return Scaffold(appBar:AppBar(title:Text(widget.section)),body:items.isEmpty?const Center(child:Padding(padding:EdgeInsets.all(30),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.folder_open_outlined,size:55,color:Colors.blueGrey),SizedBox(height:12),Text('No content added yet',style:TextStyle(fontWeight:FontWeight.w700,fontSize:17)),Text('New papers and tests added by Admin will appear here.',textAlign:TextAlign.center,style:TextStyle(color:Colors.blueGrey))]))):ListView(padding:const EdgeInsets.all(14),children:items.map((e)=>Card(child:ListTile(leading:Icon(e.kind=='Mock Test'?Icons.assignment_outlined:Icons.picture_as_pdf_outlined,color:deepBlue),title:Text(e.title,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text(e.kind=='Mock Test'?'${e.questions.length} questions • ${e.duration} min • ${e.marks} marks':e.fileName.isEmpty?'PDF content':'PDF: ${e.fileName}'),trailing:e.kind=='Mock Test'?const Icon(Icons.play_circle_outline,color:deepBlue):const Icon(Icons.download_outlined,color:deepBlue),onTap:()=>e.kind=='Mock Test'?Navigator.push(context,MaterialPageRoute(builder:(_)=>TestPage(item:e))):ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('PDF upload and download will be connected with cloud storage in the backend setup.')))))).toList()));}
}

class AdminPage extends StatefulWidget { const AdminPage({super.key}); @override State<AdminPage> createState()=>_AdminPageState(); }
class _AdminPageState extends State<AdminPage> {
  final title=TextEditingController(),duration=TextEditingController(text:'60'),marks=TextEditingController(text:'100'),negative=TextEditingController(text:'0.25'),price=TextEditingController(text:'0');
  String exam='GDCE',section='Mock Test'; bool free=true; String fileName=''; final List<Question> questions=[];
  @override void dispose(){title.dispose();duration.dispose();marks.dispose();negative.dispose();price.dispose();super.dispose();}
  Future<void> pickPdf()async{final r=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['pdf']);if(r!=null){setState(()=>fileName=r.files.single.name);}}
  Future<void> addQuestion()async{final q=await showDialog<Question>(context:context,builder:(_)=>const QuestionDialog());if(q!=null)setState(()=>questions.add(q));}
  Future<void> save()async{if(title.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Please enter a title')));return;}final item=StudyItem(id:DateTime.now().microsecondsSinceEpoch.toString(),exam:exam,section:section,title:title.text.trim(),kind:section=='Mock Test'?'Mock Test':section,fileName:fileName,questions:List.of(questions),duration:int.tryParse(duration.text)??60,marks:int.tryParse(marks.text)??100,negative:double.tryParse(negative.text)??0.25,price:free?0:(double.tryParse(price.text)??0),isFree:free);await AppStore.instance.add(item);if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Saved on this device. Cloud publishing needs Firebase setup.')));Navigator.pop(context);}}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Admin Panel')),body:ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Add new content',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:15),
    DropdownButtonFormField<String>(value:exam,decoration:const InputDecoration(labelText:'Select Exam'),items:['GDCE','LDCE'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>exam=v??'GDCE')),
    const SizedBox(height:12),DropdownButtonFormField<String>(value:section,decoration:const InputDecoration(labelText:'Content Type'),items:sections.map((e)=>DropdownMenuItem(value:e.$1,child:Text(e.$1))).toList(),onChanged:(v)=>setState(()=>section=v??'Mock Test')),
    const SizedBox(height:12),TextField(controller:title,decoration:const InputDecoration(labelText:'Title *',hintText:'e.g. GDCE Civil Mock Test 01')),
    if(section=='Mock Test')...[
      const SizedBox(height:12),Row(children:[Expanded(child:TextField(controller:duration,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Time (minutes)'))),const SizedBox(width:10),Expanded(child:TextField(controller:marks,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Total marks')))]),
      const SizedBox(height:12),TextField(controller:negative,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Negative marking per wrong answer')),
      const SizedBox(height:12),OutlinedButton.icon(onPressed:addQuestion,icon:const Icon(Icons.add),label:Text('Add Questions (${questions.length})')),
    ],
    const SizedBox(height:12),SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Free content'),value:free,onChanged:(v)=>setState(()=>free=v)),if(!free)TextField(controller:price,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Price (₹)')),
    const SizedBox(height:8),OutlinedButton.icon(onPressed:pickPdf,icon:const Icon(Icons.upload_file),label:Text(fileName.isEmpty?'Choose PDF (optional)':fileName)),
    const SizedBox(height:20),FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:mapBlue,padding:const EdgeInsets.symmetric(vertical:16)),onPressed:save,icon:const Icon(Icons.save_outlined),label:const Text('Save Content')),
    const SizedBox(height:12),const Text('Note: This starter version saves content on this device. Firebase setup is required for secure admin accounts, cloud PDF storage, cross-device publishing and paid access.',style:TextStyle(color:Colors.blueGrey,fontSize:12)),
  ]));
}

class QuestionDialog extends StatefulWidget { const QuestionDialog({super.key}); @override State<QuestionDialog> createState()=>_QuestionDialogState(); }
class _QuestionDialogState extends State<QuestionDialog>{final q=TextEditingController(),a=TextEditingController(),b=TextEditingController(),c=TextEditingController(),d=TextEditingController(),ex=TextEditingController();int answer=0;
@override Widget build(BuildContext context)=>AlertDialog(title:const Text('Add Question'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:q,decoration:const InputDecoration(labelText:'Question')),for(final entry in [('Option A',a),('Option B',b),('Option C',c),('Option D',d)])TextField(controller:entry.$2,decoration:InputDecoration(labelText:entry.$1)),DropdownButtonFormField<int>(value:answer,decoration:const InputDecoration(labelText:'Correct answer'),items:const [0,1,2,3].map((i)=>DropdownMenuItem(value:i,child:Text(['A','B','C','D'][i]))).toList(),onChanged:(v)=>setState(()=>answer=v??0)),TextField(controller:ex,decoration:const InputDecoration(labelText:'Explanation (optional)'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:(){if(q.text.trim().isEmpty||[a,b,c,d].any((x)=>x.text.trim().isEmpty))return;Navigator.pop(context,Question(text:q.text.trim(),options:[a.text,b.text,c.text,d.text],answer:answer,explanation:ex.text));},child:const Text('Add'))]);}

class TestPage extends StatefulWidget { const TestPage({super.key,required this.item});final StudyItem item;@override State<TestPage> createState()=>_TestPageState(); }
class _TestPageState extends State<TestPage>{int index=0;final Map<int,int> answers={};bool submitted=false;
void finish(){setState(()=>submitted=true);}
@override Widget build(BuildContext context){final qs=widget.item.questions;if(qs.isEmpty)return Scaffold(appBar:AppBar(title:const Text('Mock Test')),body:const Center(child:Text('Admin has not added questions to this test yet.')));if(submitted){int correct=0,wrong=0;for(var i=0;i<qs.length;i++){if(answers[i]==null)continue;if(answers[i]==qs[i].answer)correct++;else wrong++;}final score=correct*(widget.item.marks/qs.length)-wrong*widget.item.negative;return Scaffold(appBar:AppBar(title:const Text('Test Result')),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.emoji_events_outlined,color:mapBlue,size:65),const Text('Test Submitted',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text('Score: ${score.toStringAsFixed(2)} / ${widget.item.marks}'),Text('Correct: $correct   Wrong: $wrong   Unanswered: ${qs.length-correct-wrong}'),const SizedBox(height:18),FilledButton(onPressed:()=>Navigator.pop(context),child:const Text('Done'))]))));}
final q=qs[index];return Scaffold(appBar:AppBar(title:Text('Question ${index+1}/${qs.length}')),body:Column(children:[LinearProgressIndicator(value:(index+1)/qs.length,minHeight:5,color:mapBlue),Expanded(child:ListView(padding:const EdgeInsets.all(18),children:[Text(q.text,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w700)),const SizedBox(height:18),...List.generate(q.options.length,(i)=>Card(child:RadioListTile<int>(value:i,groupValue:answers[index],activeColor:mapBlue,title:Text('${String.fromCharCode(65+i)}. ${q.options[i]}'),onChanged:(v)=>setState(()=>answers[index]=v!))))])),Padding(padding:const EdgeInsets.all(16),child:Row(children:[OutlinedButton(onPressed:index==0?null:()=>setState(()=>index--),child:const Text('Previous')),const Spacer(),if(index<qs.length-1)FilledButton(onPressed:()=>setState(()=>index++),child:const Text('Save & Next'))else FilledButton(onPressed:finish,child:const Text('Submit Test'))]))]));}
}
