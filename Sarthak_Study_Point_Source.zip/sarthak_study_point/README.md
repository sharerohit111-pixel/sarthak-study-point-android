# Sarthak Study Point — Flutter starter

A focused Android app starter for Railway GDCE and LDCE preparation.

## Included in this starter
- Map-blue and white professional theme.
- Exactly two exam entry points: GDCE and LDCE.
- Four content categories under each exam: Previous Year Paper, Mock Test, Study Material, Practice Series.
- Admin content form to add items, choose exam/category, set test duration, marks, negative marking, free/paid flag and price.
- Add MCQ questions with four options and correct answer.
- Basic CBT flow with question navigation, answer selection, submit and score calculation.
- Local persistence on the device using SharedPreferences.

## Run
1. Install Flutter SDK (3.22+ recommended) and Android Studio.
2. Extract this project.
3. In this folder run:
   ```bash
   flutter pub get
   flutter run
   ```
4. To build a debug APK:
   ```bash
   flutter build apk --debug
   ```
   APK output: `build/app/outputs/flutter-apk/app-debug.apk`.

## Important production work still required
This is a working local-first starter, not yet a publish-ready multi-user service. The Admin button currently opens the local content manager without secure authentication. Content is saved only on the same device. PDF selection records the file name but does not yet upload or distribute the PDF. Paid access is only a stored price field; no payment is collected.

Before real student use, connect Firebase Authentication, Cloud Firestore and Firebase Storage; enforce admin-only writes with Firestore/Storage security rules; store PDFs in cloud storage; add server-verified payment integration (for example Razorpay) before unlocking paid content; and test the exam flow thoroughly. Do not put admin passwords or payment secrets in client code.
