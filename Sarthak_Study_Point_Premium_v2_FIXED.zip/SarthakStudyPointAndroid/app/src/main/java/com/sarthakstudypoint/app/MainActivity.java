package com.sarthakstudypoint.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://sarthak-study-point.pages.dev/";
    private static final String SITE_HOST = "sarthak-study-point.pages.dev";
    private LinearLayout root, header;
    private ScrollView dashboard;
    private WebView webView;
    private ProgressBar progress;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_PICKER_REQUEST = 4102;
    private boolean webMode = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.rgb(7, 20, 46));
        getWindow().setNavigationBarColor(Color.rgb(7, 20, 46));

        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(246,248,252));
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> { Insets b=insets.getInsets(WindowInsetsCompat.Type.systemBars()); v.setPadding(0,b.top,0,b.bottom); return insets; });
        buildHeader(); buildDashboard(); buildWebView();
        setContentView(root); showDashboard();
    }

    private void buildHeader() {
        header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(20),dp(15),dp(20),dp(15));
        header.setBackground(gradient(new int[]{Color.rgb(7,20,46),Color.rgb(20,55,111)}, dp(0)));
        TextView brand = text("SARTHAK STUDY POINT",20,Color.WHITE,true); header.addView(brand);
        TextView owner = text("ROHIT KUMAR  •  FOUNDER | OWNER",12,Color.rgb(255,199,75),true); owner.setPadding(0,dp(5),0,0); header.addView(owner);
        root.addView(header,new LinearLayout.LayoutParams(-1,-2));
    }

    private void buildDashboard() {
        dashboard = new ScrollView(this); dashboard.setFillViewport(true);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16),dp(16),dp(16),dp(28)); dashboard.addView(content);

        LinearLayout welcome = new LinearLayout(this); welcome.setOrientation(LinearLayout.VERTICAL); welcome.setPadding(dp(20),dp(22),dp(20),dp(22));
        welcome.setBackground(gradient(new int[]{Color.rgb(9,24,54),Color.rgb(29,74,145)},dp(22)));
        TextView eyebrow=text("YOUR NEXT STEP STARTS HERE",11,Color.rgb(183,210,255),true); welcome.addView(eyebrow);
        TextView hero=text("Prepare smarter.\nAchieve bigger.",29,Color.WHITE,true); hero.setPadding(0,dp(10),0,dp(5)); welcome.addView(hero);
        TextView sub=text("एक ही मंच पर सभी प्रतियोगी परीक्षाओं की तैयारी",14,Color.rgb(224,235,255),false); welcome.addView(sub);
        Button explore=button("Explore Courses  →",Color.WHITE,Color.rgb(17,48,100)); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-2,dp(46)); ep.topMargin=dp(18); welcome.addView(explore,ep); explore.setOnClickListener(v->openWebsite());
        content.addView(welcome);

        LinearLayout section=sectionTitle("Explore Exams","अपनी परीक्षा चुनें और तैयारी शुरू करें"); content.addView(section);
        String[][] exams={{"🚆","Railway Exams","RRB • GDCE • LDCE • JE"},{"📘","SSC & Government Jobs","CGL • CHSL • MTS • अन्य"},{"🏦","Banking Exams","IBPS • SBI • RBI"},{"🎓","UPSC & State PCS","Civil Services • State Exams"},{"🧑‍🏫","Teaching Exams","CTET • TET • शिक्षक भर्ती"},{"📝","Other Competitive Exams","Police • Defence • अन्य"}};
        for(int i=0;i<exams.length;i+=2){ LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); for(int j=i;j<Math.min(i+2,exams.length);j++) row.addView(examCard(exams[j][0],exams[j][1],exams[j][2]),new LinearLayout.LayoutParams(0,dp(122),1)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.topMargin=dp(10); content.addView(row,rp); }

        content.addView(sectionTitle("Continue Learning","अभ्यास, नोट्स और मॉक टेस्ट"));
        LinearLayout tools = new LinearLayout(this); tools.setOrientation(LinearLayout.VERTICAL); tools.setPadding(dp(15),dp(5),dp(15),dp(5)); tools.setBackground(round(Color.WHITE,dp(18)));
        tools.addView(actionRow("⏱","Online Mock Tests","समयबद्ध परीक्षा और परिणाम",v->openWebsite()));
        tools.addView(separator());
        tools.addView(actionRow("📚","Practice & Study PDFs","अध्ययन सामग्री और प्रश्नपत्र",v->openWebsite()));
        tools.addView(separator());
        tools.addView(actionRow("📊","Performance & Analysis","अपनी तैयारी की प्रगति देखें",v->openWebsite()));
        content.addView(tools);

        LinearLayout quick = new LinearLayout(this); quick.setOrientation(LinearLayout.HORIZONTAL); quick.setPadding(0,dp(14),0,0);
        Button cbt=button("GDCE JE Civil CBT",Color.WHITE,Color.rgb(22,83,170)); quick.addView(cbt,new LinearLayout.LayoutParams(0,dp(48),1)); cbt.setOnClickListener(v->loadCbt());
        Button pdf=button("Practice PDF",Color.rgb(22,83,170),Color.WHITE); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,dp(48),1); pp.leftMargin=dp(8); quick.addView(pdf,pp); pdf.setOnClickListener(v->openPracticePdf()); content.addView(quick);

        TextView footer=text("Learn  •  Practice  •  Succeed\nSARTHAK STUDY POINT",11,Color.rgb(105,117,139),true); footer.setGravity(Gravity.CENTER); footer.setPadding(0,dp(25),0,dp(5)); content.addView(footer);
        root.addView(dashboard,new LinearLayout.LayoutParams(-1,0,1));
    }

    private View examCard(String icon,String title,String desc){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(13),dp(13),dp(10),dp(10)); card.setBackground(round(Color.WHITE,dp(16)));
        TextView ic=text(icon,23,Color.rgb(25,78,155),true); card.addView(ic);
        TextView t=text(title,14,Color.rgb(19,35,65),true); t.setPadding(0,dp(6),0,dp(3)); card.addView(t);
        TextView d=text(desc,10,Color.rgb(105,117,139),false); card.addView(d);
        card.setElevation(dp(2)); card.setOnClickListener(v->openWebsite()); return card;
    }
    private LinearLayout sectionTitle(String title,String subtitle){ LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(0,dp(22),0,dp(4)); TextView t=text(title,19,Color.rgb(17,33,62),true); box.addView(t); TextView s=text(subtitle,12,Color.rgb(112,124,145),false); s.setPadding(0,dp(3),0,0); box.addView(s); return box; }
    private View actionRow(String icon,String title,String desc,View.OnClickListener click){ LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0,dp(12),0,dp(12)); TextView ic=text(icon,22,Color.rgb(28,83,164),true); r.addView(ic,new LinearLayout.LayoutParams(dp(42),-2)); LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.addView(text(title,14,Color.rgb(25,39,66),true)); c.addView(text(desc,11,Color.rgb(115,126,146),false)); r.addView(c,new LinearLayout.LayoutParams(0,-2,1)); TextView arrow=text("›",26,Color.rgb(100,119,150),true); r.addView(arrow); r.setOnClickListener(click); return r; }
    private View separator(){ View v=new View(this); v.setBackgroundColor(Color.rgb(235,239,245)); v.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(1))); return v; }

    private void buildWebView(){
        FrameLayout frame=new FrameLayout(this); progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(100);
        webView=new WebView(this); WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setSupportZoom(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){ Uri u=request.getUrl(); if("https".equalsIgnoreCase(u.getScheme())&&SITE_HOST.equalsIgnoreCase(u.getHost())) return false; if("file".equalsIgnoreCase(u.getScheme())||"about".equalsIgnoreCase(u.getScheme())) return false; openExternal(u); return true; } @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame()) showOfflinePage();} });
        webView.setWebChromeClient(new WebChromeClient(){ @Override public void onProgressChanged(WebView v,int p){progress.setProgress(p);progress.setVisibility(p>=100?View.GONE:View.VISIBLE);} @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(uploadCallback!=null)uploadCallback.onReceiveValue(null);uploadCallback=cb;Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");try{startActivityForResult(Intent.createChooser(i,"Select study material"),FILE_PICKER_REQUEST);return true;}catch(Exception e){uploadCallback=null;return false;}} });
        webView.setDownloadListener((url,ua,cd,mime,len)->{try{DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));req.setMimeType(mime);String cookie=CookieManager.getInstance().getCookie(url);if(cookie!=null)req.addRequestHeader("cookie",cookie);req.addRequestHeader("User-Agent",ua);String name=URLUtil.guessFileName(url,cd,mime);req.setTitle(name);req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,name);((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);}catch(Exception e){Toast.makeText(this,"Download failed",Toast.LENGTH_SHORT).show();}});
        frame.addView(webView,new FrameLayout.LayoutParams(-1,-1)); frame.addView(progress,new FrameLayout.LayoutParams(-1,dp(3),Gravity.TOP)); root.addView(frame,new LinearLayout.LayoutParams(-1,0,1)); frame.setTag("webFrame"); frame.setVisibility(View.VISIBLE); webView.setVisibility(View.GONE); progress.setVisibility(View.GONE);
    }
    private void showDashboard(){webMode=false; dashboard.setVisibility(View.VISIBLE); webView.setVisibility(View.GONE); progress.setVisibility(View.GONE); }
    private void showWeb(){webMode=true; dashboard.setVisibility(View.GONE); webView.setVisibility(View.VISIBLE); }
    private void openWebsite(){showWeb();webView.loadUrl(HOME_URL);}
    private void loadCbt(){showWeb();webView.loadUrl("file:///android_asset/gdce_je_civil_cbt.html");}
    private void openPracticePdf(){try{File f=new File(getCacheDir(),"GDCE_JE_Civil_Practice_Paper_Hindi.pdf");try(InputStream in=getAssets().open("gdce_je_civil_practice_paper_hindi.pdf");FileOutputStream out=new FileOutputStream(f)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}Uri u=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(u,"application/pdf");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Open Practice PDF"));}catch(Exception e){Toast.makeText(this,"PDF viewer उपलब्ध नहीं है।",Toast.LENGTH_LONG).show();}}
    private void openExternal(Uri u){try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}}
    private void showOfflinePage(){webView.loadData("<meta name='viewport' content='width=device-width,initial-scale=1'><body style='font-family:Arial;padding:25px;background:#f4f7fb'><h2>Sarthak Study Point</h2><h3>इंटरनेट कनेक्शन उपलब्ध नहीं है</h3><p>कृपया इंटरनेट चालू करके पुनः प्रयास करें।</p></body>","text/html","UTF-8");}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String label,int bg,int fg){Button b=new Button(this);b.setText(label);b.setTextSize(12);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextColor(fg);b.setBackground(round(bg,dp(13)));return b;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    private GradientDrawable gradient(int[] colors,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);d.setCornerRadius(radius);return d;}
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==FILE_PICKER_REQUEST&&uploadCallback!=null){Uri[] result=null;if(c==RESULT_OK&&d!=null&&d.getData()!=null)result=new Uri[]{d.getData()};uploadCallback.onReceiveValue(result);uploadCallback=null;}}
    @Override public void onBackPressed(){if(webMode){if(webView.canGoBack())webView.goBack();else showDashboard();}else super.onBackPressed();}
    @Override protected void onDestroy(){if(uploadCallback!=null)uploadCallback.onReceiveValue(null);if(webView!=null)webView.destroy();super.onDestroy();}
}
