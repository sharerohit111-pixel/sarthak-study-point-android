# Sarthak Study Point Android — Premium v2.0

A mobile-first Android app shell for the Sarthak Study Point learning platform.

## What's new in v2.0
- Premium native dashboard with a navy/blue visual system.
- Exam discovery sections for Railway, SSC/Government Jobs, Banking, UPSC/State PCS, Teaching and other competitive exams.
- Quick access to the live learning website, bundled GDCE JE Civil CBT and offline Hindi practice PDF.
- Founder branding: Rohit Kumar — Founder | Owner.
- WebView file upload and download support retained.

## Build
Open this folder in Android Studio and run `:app:assembleDebug`, or use the GitHub Actions workflow included in `.github/workflows/android-build.yml`.

The app is a first production-design iteration, not yet a complete Testbook-scale platform. Live accounts, secure admin roles, central question bank, subscriptions/payments, analytics and backend services must be implemented and security-tested before public commercial launch.
